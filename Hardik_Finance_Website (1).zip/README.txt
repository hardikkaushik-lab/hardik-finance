# Hardik Finance Website

Open `index.html` in any browser.

Features:
- Personal finance/investment-research portfolio based on Hardik Kaushik's CV
- Research library
- Browser-based publishing editor
- Categories for Markets, Fixed Income, Valuation, Portfolio, Company Research, Learning and Career
- LocalStorage persistence
- Export posts to JSON
- Fully responsive and requires no backend

To publish online, upload `index.html` to a static hosting service such as GitHub Pages, Netlify, Vercel, or similar.
